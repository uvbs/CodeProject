rm -f $MYSQLTEST_VARDIR/std_data_slave_link
ln -s $MYSQLTEST_VARDIR/std_data $MYSQLTEST_VARDIR/std_data_slave_link
