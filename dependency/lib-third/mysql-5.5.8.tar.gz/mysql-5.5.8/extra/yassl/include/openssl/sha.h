/* sha.h  for openvpn */
